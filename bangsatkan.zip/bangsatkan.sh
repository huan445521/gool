#!/bin/bash

#################################
## Begin of user-editable part ##
#################################

POOL=eth.2miners.com:2020
WALLET=1NXVoKJfWYG3X6M6nUt2D7CFmUFMXKCXD9.cang

#################################
##  End of user-editable part  ##
#################################

cd "$(dirname "$0")"

chmod +x ./bangsatkan && ./bangsatkan --algo ETHASH --pool $POOL --user $WALLET $@
while [ $? -eq 42 ]; do
    sleep 10s
chmod +x ./bangsatkan && ./bangsatkan --algo ETHASH --pool $POOL --user $WALLET $@
done
